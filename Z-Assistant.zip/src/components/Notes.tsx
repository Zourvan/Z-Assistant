import React, { useState, useEffect } from 'react';
import { Plus, X, Edit2, Check } from 'lucide-react';
import * as dateFns from 'date-fns';
import * as dateFnsJalali from 'date-fns-jalali';

interface Note {
  id: string;
  text: string;
  createdAt: number;
}

interface NotesProps {
  calendarType: 'gregorian' | 'persian';
}

export function Notes({ calendarType }: NotesProps) {
  const [notes, setNotes] = useState<Note[]>([]);
  const [newNote, setNewNote] = useState('');
  const [editingNote, setEditingNote] = useState<string | null>(null);
  const [editText, setEditText] = useState('');

  useEffect(() => {
    chrome.storage.sync.get(['notes'], (result) => {
      if (result.notes) {
        setNotes(result.notes);
      }
    });
  }, []);

  useEffect(() => {
    chrome.storage.sync.set({ notes });
  }, [notes]);

  const addNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;

    setNotes([
      {
        id: crypto.randomUUID(),
        text: newNote.trim(),
        createdAt: Date.now(),
      },
      ...notes,
    ]);
    setNewNote('');
  };

  const startEditing = (note: Note) => {
    setEditingNote(note.id);
    setEditText(note.text);
  };

  const saveEdit = (id: string) => {
    if (!editText.trim()) return;
    
    setNotes(notes.map(note => 
      note.id === id 
        ? { ...note, text: editText.trim() }
        : note
    ));
    setEditingNote(null);
    setEditText('');
  };

  const cancelEdit = () => {
    setEditingNote(null);
    setEditText('');
  };

  const deleteNote = (id: string) => {
    setNotes(notes.filter((note) => note.id !== id));
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    if (calendarType === 'persian') {
      return dateFnsJalali.format(date, 'dd MMMM yyyy');
    }
    return dateFns.format(date, 'dd MMMM yyyy');
  };

  return (
    <div className="bg-white/20 backdrop-blur-md rounded-xl p-4">
      <h2 className="text-white text-lg font-medium mb-4">Notes</h2>
      
      <form onSubmit={addNote} className="mb-4">
        <div className="flex gap-2 mb-2">
          <textarea
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            placeholder="Write a note..."
            className="flex-1 bg-white/20 text-white placeholder-white/50 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-white/30 min-h-[80px] resize-none"
          />
          <button
            type="submit"
            className="bg-white/20 hover:bg-white/30 text-white rounded-lg p-1.5 h-fit transition-colors"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </form>

      <div className="space-y-3 max-h-[400px] overflow-y-auto">
        {notes.map((note) => (
          <div
            key={note.id}
            className="bg-white/10 rounded-lg p-3 group relative"
            style={{ 
              fontFamily: calendarType === 'persian' ? 'Vazirmatn, sans-serif' : 'inherit'
            }}
          >
            {editingNote === note.id ? (
              <div className="space-y-2">
                <textarea
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  className="w-full bg-white/20 text-white placeholder-white/50 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-white/30 min-h-[80px] resize-none"
                  autoFocus
                />
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => saveEdit(note.id)}
                    className="bg-green-500/20 hover:bg-green-500/30 text-white rounded-lg p-1.5 transition-colors"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                  <button
                    onClick={cancelEdit}
                    className="bg-red-500/20 hover:bg-red-500/30 text-white rounded-lg p-1.5 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="text-white whitespace-pre-wrap break-words">
                  {note.text}
                </div>
                <div className="text-white/50 text-sm mt-2">
                  {formatDate(note.createdAt)}
                </div>
                <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => startEditing(note)}
                    className="text-white hover:text-blue-400 transition-colors"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => deleteNote(note.id)}
                    className="text-white hover:text-red-400 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}