import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { Image, Upload, Link, X, Palette, Settings as SettingsIcon, Calendar, Monitor, Sun, Moon } from 'lucide-react';

interface SettingsPanelProps {
  onSelectBackground: (background: string) => void;
  calendarType: 'gregorian' | 'persian';
  onCalendarTypeChange: (type: 'gregorian' | 'persian') => void;
  storageKey?: string;
}

type ThemeMode = 'light' | 'dark' | 'system';

interface StoredBackground {
  id: string;
  url: string;
  isBlob: boolean;
  type: 'image' | 'color';
  createdAt: number;
}

interface Settings {
  themeMode: ThemeMode;
  calendarType: 'gregorian' | 'persian';
  background?: StoredBackground;
}

const DB_NAME = 'backgroundSelectorDB';
const STORE_NAME = 'backgrounds';
const DB_VERSION = 1;

const isDataUrl = (url: string) => url.startsWith('data:');
const isColor = (str: string) => /^#([0-9A-F]{3}){1,2}$/i.test(str);

const processImageUrl = (url: string, width = 1920, height = 1080) => {
  if (isDataUrl(url) || isColor(url)) {
    return url;
  }
  try {
    const urlObj = new URL(url);
    urlObj.searchParams.set('auto', 'format');
    urlObj.searchParams.set('fit', 'crop');
    urlObj.searchParams.set('w', width.toString());
    urlObj.searchParams.set('h', height.toString());
    return urlObj.toString();
  } catch {
    return url;
  }
};

// Database initialization function
const initializeDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      console.error('Failed to open database:', request.error);
      reject(request.error);
    };

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      if (db.objectStoreNames.contains(STORE_NAME)) {
        db.deleteObjectStore(STORE_NAME);
      }
      
      const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      store.createIndex('type', 'type', { unique: false });
      store.createIndex('createdAt', 'createdAt', { unique: false });
    };

    request.onsuccess = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      resolve(db);
    };
  });
};

// Database operations wrapper
const createDatabaseOperations = () => {
  let db: IDBDatabase | null = null;

  const getDB = async (): Promise<IDBDatabase> => {
    if (!db) {
      db = await initializeDB();
    }
    return db;
  };

  const saveBackground = async (background: StoredBackground): Promise<void> => {
    const database = await getDB();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.put(background);

      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  };

  const getAllBackgrounds = async (): Promise<StoredBackground[]> => {
    const database = await getDB();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();

      transaction.oncomplete = () => resolve(request.result || []);
      transaction.onerror = () => reject(transaction.error);
    });
  };

  const deleteBackground = async (id: string): Promise<void> => {
    const database = await getDB();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.delete(id);

      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  };

  return {
    saveBackground,
    getAllBackgrounds,
    deleteBackground
  };
};

const BackgroundThumbnail: React.FC<{
  bg: StoredBackground;
  onSelect: () => void;
  onRemove?: () => void;
}> = ({ bg, onSelect, onRemove }) => {
  const [isLoading, setIsLoading] = useState(bg.type === 'image');
  const [error, setError] = useState(false);

  return (
    <div className="relative group aspect-square">
      <button
        onClick={onSelect}
        className="w-full h-full rounded-lg overflow-hidden hover:opacity-80 transition-opacity"
        style={bg.type === 'color' ? { backgroundColor: bg.url } : {}}
      >
        {bg.type === 'image' && (
          <>
            {isLoading && (
              <div className="absolute inset-0 flex items-center justify-center bg-slate-200 animate-pulse">
                <Image className="w-6 h-6 text-slate-400" />
              </div>
            )}
            {error ? (
              <div className="absolute inset-0 flex items-center justify-center bg-red-100">
                <X className="w-6 h-6 text-red-400" />
              </div>
            ) : (
              <img 
                src={bg.url}
                alt="Background option"
                className={`w-full h-full object-cover transition-opacity duration-300 ${isLoading ? 'opacity-0' : 'opacity-100'}`}
                loading="lazy"
                onLoad={() => setIsLoading(false)}
                onError={() => {
                  setIsLoading(false);
                  setError(true);
                }}
              />
            )}
          </>
        )}
      </button>
      {bg.isBlob && onRemove && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="absolute -top-2 -right-2 bg-red-500 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <X className="w-3 h-3 text-white" />
        </button>
      )}
    </div>
  );
};

export const SettingsPanel: React.FC<SettingsPanelProps> = ({ 
  onSelectBackground,
  calendarType,
  onCalendarTypeChange,
  storageKey = 'settings'
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'backgrounds' | 'appearance'>('backgrounds');
  const [urlInput, setUrlInput] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [savedBackgrounds, setSavedBackgrounds] = useState<StoredBackground[]>([]);
  const [themeMode, setThemeMode] = useState<ThemeMode>('system');
  const [tileNumber, setTileNumber] = useState(30);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dbOps = createDatabaseOperations();

  const defaultBackgrounds = useMemo(() => [
    '/static/background/img-6.gif',
'/static/background/img-1.jpg',
'/static/background/img-2.jpg',
'/static/background/img-3.jpg',
'/static/background/img-4.jpg',
'/static/background/img-5.jpg'
  ].map(url => ({
    id: url,
    url,
    isBlob: false,
    type: 'image' as const,
    createdAt: Date.now()
  })), []);

  const colorOptions = useMemo(() => [
    '#000000', '#FFFFFF', '#1E40AF', '#047857', '#B45309', '#9F1239',
    '#4C1D95', '#831843', '#3730A3', '#064E3B', '#701A75', '#7C2D12'
  ].map(color => ({
    id: color,
    url: color,
    isBlob: false,
    type: 'color' as const,
    createdAt: Date.now()
  })), []);

  const loadSavedBackgrounds = useCallback(async () => {
    try {
      const backgrounds = await dbOps.getAllBackgrounds();
      setSavedBackgrounds(backgrounds);
    } catch (error) {
      console.error('Error loading backgrounds:', error);
      setSavedBackgrounds([]);
    }
  }, []);

  const handleTileNumberChange = (event) => {
    const value = parseInt(event.target.value);
    if (value >= 10 && value <= 100) {
      setTileNumber(value);
      // Store in localStorage
      localStorage.setItem('tileNumber', value.toString());
      // Call the function to notify other components
      onTileNumberChange(value);
    }
  };

  useEffect(() => {
    loadSavedBackgrounds();

    // Load saved settings
    const savedSettings = localStorage.getItem(storageKey);
    if (savedSettings) {
      try {
        const settings: Settings = JSON.parse(savedSettings);
        setThemeMode(settings.themeMode || 'system');
      } catch (error) {
        console.error('Error loading settings:', error);
      }
    }

    // Apply theme based on system preference if needed
    if (themeMode === 'system') {
      const darkModeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const handleChange = (e: MediaQueryListEvent) => {
        document.documentElement.classList.toggle('dark', e.matches);
      };
      darkModeMediaQuery.addEventListener('change', handleChange);
      return () => darkModeMediaQuery.removeEventListener('change', handleChange);
    }
  }, [loadSavedBackgrounds, storageKey]);

  useEffect(() => {
    const storedTileNumber = localStorage.getItem('tileNumber');
    if (storedTileNumber) {
      setTileNumber(parseInt(storedTileNumber));
    }
  }, []);

  const onTileNumberChange = (value) => {
    // Dispatch a custom event that other components can listen to
    const event = new CustomEvent('tileNumberChange', { detail: value });
    window.dispatchEvent(event);
  };

  useEffect(() => {
    // Save settings
    const settings: Settings = {
      themeMode,
      calendarType
    };
    localStorage.setItem(storageKey, JSON.stringify(settings));

    // Apply theme
    if (themeMode === 'system') {
      const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      document.documentElement.classList.toggle('dark', isDark);
    } else {
      document.documentElement.classList.toggle('dark', themeMode === 'dark');
    }
  }, [themeMode, calendarType, storageKey]);

  const handleSelectBackground = useCallback((background: StoredBackground) => {
    const finalUrl = background.type === 'image' && !isDataUrl(background.url) ? 
      processImageUrl(background.url) : 
      background.url;
      
    onSelectBackground(finalUrl);
    const settings: Settings = {
      themeMode,
      calendarType,
      background
    };
    localStorage.setItem(storageKey, JSON.stringify(settings));
    setIsOpen(false);
  }, [onSelectBackground, storageKey, themeMode, calendarType]);

  const handleFileUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    try {
      setIsUploading(true);
      
      const reader = new FileReader();
      reader.onload = async (e) => {
        const dataUrl = e.target?.result as string;
        if (dataUrl) {
          const newBackground: StoredBackground = {
            id: `bg-${Date.now()}`,
            url: dataUrl,
            isBlob: true,
            type: 'image',
            createdAt: Date.now()
          };
          
          await dbOps.saveBackground(newBackground);
          await loadSavedBackgrounds();
          handleSelectBackground(newBackground);
        }
      };
      reader.readAsDataURL(file);
      
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (error) {
      alert('Error uploading image');
    } finally {
      setIsUploading(false);
    }
  }, [handleSelectBackground, loadSavedBackgrounds]);

  const handleUrlSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;

    try {
      new URL(urlInput);
      if (!/\.(jpg|jpeg|png|gif|webp)$/i.test(urlInput)) {
        alert('Please enter a valid image URL');
        return;
      }

      const newBackground: StoredBackground = {
        id: `bg-${Date.now()}`,
        url: urlInput,
        isBlob: false,
        type: 'image',
        createdAt: Date.now()
      };
      
      await dbOps.saveBackground(newBackground);
      await loadSavedBackgrounds();
      handleSelectBackground(newBackground);
      setUrlInput('');
    } catch {
      alert('Please enter a valid URL');
    }
  }, [urlInput, handleSelectBackground, loadSavedBackgrounds]);

  const handleRemoveBackground = useCallback(async (backgroundToRemove: StoredBackground) => {
    try {
      await dbOps.deleteBackground(backgroundToRemove.id);
      await loadSavedBackgrounds();

      const savedSettings = localStorage.getItem(storageKey);
      if (savedSettings) {
        const settings: Settings = JSON.parse(savedSettings);
        if (settings.background?.id === backgroundToRemove.id) {
          handleSelectBackground(defaultBackgrounds[0]);
        }
      }
    } catch (error) {
      console.error('Error removing background:', error);
    }
  }, [defaultBackgrounds, storageKey, handleSelectBackground, loadSavedBackgrounds]);

  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col items-end">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-white/20 backdrop-blur-md p-2 rounded-full hover:bg-white/30 transition-colors shadow-lg"
      >
        <SettingsIcon className="w-5 h-5 text-white" />
      </button>

      {isOpen && (
        <div className="mt-2 bg-white/20 backdrop-blur-md rounded-xl p-4 w-80 shadow-lg">
          <div className="flex gap-2 mb-4">
            <button
              onClick={() => setActiveTab('backgrounds')}
              className={`flex-1 px-3 py-2 rounded-lg text-sm flex items-center justify-center gap-2 ${
                activeTab === 'backgrounds' ? 'bg-white/30' : 'hover:bg-white/20'
              } transition-colors text-white`}
            >
              <Image className="w-4 h-4" />
              Backgrounds
            </button>
            <button
              onClick={() => setActiveTab('appearance')}
              className={`flex-1 px-3 py-2 rounded-lg text-sm flex items-center justify-center gap-2 ${
                activeTab === 'appearance' ? 'bg-white/30' : 'hover:bg-white/20'
              } transition-colors text-white`}
            >
              <Palette className="w-4 h-4" />
              Appearance
            </button>
          </div>

          {activeTab === 'backgrounds' ? (
            <>
              <div className="grid grid-cols-3 gap-2 mb-4">
                {[...defaultBackgrounds, ...savedBackgrounds.filter(bg => bg.type === 'image')].map((bg) => (
                  <BackgroundThumbnail
                    key={bg.id}
                    bg={bg}
                    onSelect={() => handleSelectBackground(bg)}
                    onRemove={bg.isBlob ? () => handleRemoveBackground(bg) : undefined}
                  />
                ))}
              </div>

              <div className="space-y-4">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full bg-white/30 hover:bg-white/40 transition-colors px-4 py-2 rounded-lg text-sm text-white flex items-center justify-center gap-2"
                  disabled={isUploading}
                >
                  <Upload className="w-4 h-4" />
                  {isUploading ? 'Uploading...' : 'Upload Image'}
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,.gif"
                  onChange={handleFileUpload}
                  className="hidden"
                />

                <form onSubmit={handleUrlSubmit} className="flex gap-2">
                  <input
                    type="text"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    placeholder="Paste image URL"
                    className="flex-1 bg-white/30 hover:bg-white/40 focus:bg-white/40 transition-colors px-4 py-2 rounded-lg text-sm text-white placeholder-white/50 outline-none"
                  />
                  <button
                    type="submit"
                    className="bg-white/30 hover:bg-white/40 transition-colors p-2 rounded-lg text-white"
                  >
                    <Link className="w-4 h-4" />
                  </button>
                </form>
              </div>
            </>
          ) : (
            <div className="space-y-6">
              {/* Tile Number Input */}
      <div className="space-y-2">
        <h3 className="text-white text-sm font-medium">Tile Number</h3>
        <div className="flex items-center">
          <input
            type="number"
            min="10"
            max="100"
            value={tileNumber}
            onChange={handleTileNumberChange}
            className="w-full px-3 py-2 rounded-lg text-sm bg-white/10 text-white border border-white/20 focus:outline-none focus:border-white/30"
          />
        </div>
      </div>
              {/* Calendar Type */}
              <div className="space-y-2">
                <h3 className="text-white text-sm font-medium">Calendar Type</h3>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => onCalendarTypeChange('gregorian')}
                    className={`flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm ${
                      calendarType === 'gregorian' ? 'bg-white/30' : 'bg-white/10 hover:bg-white/20'
                    } transition-colors text-white`}
                  >
                    <Calendar className="w-4 h-4" />
                    Gregorian
                  </button>
                  <button
                    onClick={() => onCalendarTypeChange('persian')}
                    className={`flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm ${
                      calendarType === 'persian' ? 'bg-white/30' : 'bg-white/10 hover:bg-white/20'
                    } transition-colors text-white`}
                  >
                    <Calendar className="w-4 h-4" />
                    Persian
                  </button>
                </div>
              </div>

              {/* Theme Mode */}
              <div className="space-y-2">
                <h3 className="text-white text-sm font-medium">Theme Mode</h3>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setThemeMode('light')}
                    className={`flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm ${
                      themeMode === 'light' ? 'bg-white/30' : 'bg-white/10 hover:bg-white/20'
                    } transition-colors text-white`}
                  >
                    <Sun className="w-4 h-4" />
                    Light
                  </button>
                  <button
                    onClick={() => setThemeMode('dark')}
                    className={`flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm ${
                      themeMode === 'dark' ? 'bg-white/30' : 'bg-white/10 hover:bg-white/20'
                    } transition-colors text-white`}
                  >
                    <Moon className="w-4 h-4" />
                    Dark
                  </button>
                  <button
                    onClick={() => setThemeMode('system')}
                    className={`flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm ${
                      themeMode === 'system' ? 'bg-white/30' : 'bg-white/10 hover:bg-white/20'
                    } transition-colors text-white`}
                  >
                    <Monitor className="w-4 h-4" />
                    System
                  </button>
                </div>
              </div>

              {/* Solid Colors */}
              <div className="space-y-2">
                <h3 className="text-white text-sm font-medium">Solid Colors</h3>
                <div className="grid grid-cols-4 gap-2">
                  {colorOptions.map((color) => (
                    <BackgroundThumbnail
                      key={color.id}
                      bg={color}
                      onSelect={() => handleSelectBackground(color)}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SettingsPanel;