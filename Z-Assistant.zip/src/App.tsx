import React, { useState, useEffect } from 'react';
import { Clock } from './components/Clock';
import { Calendar } from './components/Calendar';
import { Bookmarks } from './components/Bookmarks';
import { SettingsPanel } from './components/BackgroundSelector';
import { TodoList } from './components/TodoList';
import { Notes } from './components/Notes';

function App() {
  const [background, setBackground] = useState('https://images.unsplash.com/photo-1464822759023-fed622ff2c3b');
  const [calendarType, setCalendarType] = useState<'gregorian' | 'persian'>(() => {
    const saved = localStorage.getItem('calendarType');
    return (saved === 'persian' || saved === 'gregorian') ? saved : 'gregorian';
  });

  useEffect(() => {
    localStorage.setItem('calendarType', calendarType);
  }, [calendarType]);

  return (
    <div 
      className="min-h-screen bg-cover bg-center"
      style={{ 
        backgroundImage: `url(${background}?auto=format&fit=crop&w=1920&h=1080)`,
      }}
    >
      <div className="min-h-screen bg-black/30 p-4 md:p-8">
        <div className="max-w-[1400px] mx-auto grid grid-cols-1 lg:grid-cols-[30%_1fr] gap-8">
          {/* Left side */}
          <div className="space-y-8">
            <Clock calendarType={calendarType} />
            <Calendar calendarType={calendarType} />
            <TodoList />
            <Notes calendarType={calendarType} />
          </div>

          {/* Right side */}
          <div>
            <Bookmarks />
          </div>
        </div>

        <SettingsPanel 
          onSelectBackground={setBackground}
          calendarType={calendarType}
          onCalendarTypeChange={setCalendarType}
        />
      </div>
    </div>
  );
}

export default App;